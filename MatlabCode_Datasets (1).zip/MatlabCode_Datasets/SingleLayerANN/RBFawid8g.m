%Single Layer Radial Basis Function

close all;clear all;clc;
f = 26; % Number of features in Dataset
rows1 = 30; %Number of rows in Dataset
x1 = load('RBF_dataset.txt'); %abs(randn(f,rows1));   %Simulated Dataset
x = [x1;ones(1,rows1)];    
y  = [0 1 0 0 1 1 0 0 0 1 0 0 0 0 0 1 0 1 1 0 1 0 0 0 0 1 0 0 1 0];
alpha =0.5; %Learning Rate
%% Random Values Weights,
W1 = load('W1_RBF.txt'); %randi([-1 1],f+1,f)';
W1a = load('W1a_RBF.txt'); %randi([-1 1],f+1,f)';
W2 =  load('W2_RBF.txt')'; %randi([-1 1],f+1,1)';
rows = 1;
n = rows1;
for i = 1:100000
    for j = 1 
        for m = 1:rows1
            %% Forward Propagation
            %% 1st Layer
            a1 = W1*x(:,m);
            h1 = 1./(1+exp(-a1));
            h1 = [h1; ones(1,rows)];
            %% 2nd Layer
            a2 = W1a*h1;
            h2 = 1./(1+exp(-a2));
            h2 = [h2; ones(1,rows)];
            %% Output Layer
            aa1_3 = W2*h2;
            h11_3 = 1./(1+exp(-aa1_3));
            v1 = (1-h11_3)'*h11_3;
            v2 = (h11_3' - y(m));
            del11_3 = v1*v2;
            %% Backward Propagation
            % Output Layer Weights
            a22 = h2*del11_3;
            W2 = W2'-alpha.*a22;
            %% 2nd Hidden Layer Weights
            u1 = h2(1:end-1,:)'*(1-h2(1:end-1,:));
            u2 = del11_3*W2(1:end-1)';
            u3 = u1*u2;
            u4 = x(:,m)*u3;
            W1a = W1a' - alpha.*u4;
            %% 1st Hidden Layer Weights
            s1 = h2(1:end-1,:)'*(1-h2(1:end-1,:))*h1(1:end-1,:)'*(1-h1(1:end-1,:));
            s2 = del11_3*W2(1:end-1)';
            s3 = s1*s2;
            s4 = x(:,m)*s3;
            W1 = W1' - alpha.*s4;
            %%
            W1 = W1';
            W1a = W1a';
            W2 = W2';
            new_h11_3(m) = h11_3;
            new_y(m) = y(m);
            % test = [h11_3' y(m)]
        end
    end
   % test = [h11_3' y(m)]
    test = [new_h11_3(:) new_y(:)]
end
