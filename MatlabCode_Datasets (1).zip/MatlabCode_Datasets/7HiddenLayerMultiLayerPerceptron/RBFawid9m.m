%7 hidden Layer MLP

close all;clear all;clc;
f = 26; %Number of features in dataset
rows1 = 30;  %Number of rows in dataset
% x1 = abs(randn(f,rows1));
x1 =   load('7layerMLP_dataset.txt');  % Simulated Dataset, normalized
% x2 = abs(randn(1,rows1));
x = [x1;ones(1,rows1)];
y  = [0 1 0 0 1 1 0 0 0 1 0 0 0 0 0 1 0 1 1 0 1 0 0 0 0 1 0 0 1 0];
alpha = 0.007; %Learning Rate
%% Random Values Weights,
W1 = load('W1_7layerMLP.txt'); %randi([-1 1],f+1,f)';
W1a = load('W1a_7layerMLP.txt')'; % randi([-1 1],f+1,f)'; 
W1b = load('W1b_7layerMLP.txt')'; % randi([-1 1],f+1,f)';
W1c = load('W1c_7layerMLP.txt')'; % randi([-1 1],f+1,f)';
W1d = load('W1d_7layerMLP.txt')'; %randi([-1 1],f+1,f)';
W1e = load('W1e_7layerMLP.txt')'; %randi([-1 1],f+1,f)';
W1f = load('W1f_7layerMLP.txt')'; %randi([-1 1],f+1,f)';
W1g = load('W1g_7layerMLP.txt')'; %randi([-1 1],f+1,f)';
% W1h = randi([-1 1],f+1,f)';
% W1i = randi([-1 1],f+1,f)';
% W1j = randi([-1 1],f+1,f)';
% W1k = randi([-1 1],f+1,f)';
% W1l = randi([-1 1],f+1,f)';
W2 =  load('W2_7layerMLP.txt')'; %randi([-1 1],f+1,1)'; 
rows = 1;
n = rows1;
for i = 1:100000
    for j = 1
        m1 = n*(j-1)+1;
        m2 = n*(j-1)+n;       
        for m = 1:rows1
            %% Forward Propagation
            %% 1st Layer
            a1 = W1*x(:,m);
            h1 = 1./(1+exp(-a1));
            h1 = [h1; ones(1,rows)];
            %% 2nd Layer
            a2 = W1a*h1;
            h2 = 1./(1+exp(-a2));
            h2 = [h2; ones(1,rows)];            
            %% 3rd Layer
            a3 = W1b*h2;
            h3 = 1./(1+exp(-a3));
            h3 = [h3; ones(1,rows)];            
            %% 4rth Layer
            a4 = W1c*h3;
            h4 = 1./(1+exp(-a4));
            h4 = [h4; ones(1,rows)];            
             %% 5th Layer
            a5 = W1d*h4;
            h5 = 1./(1+exp(-a5));
            h5 = [h5; ones(1,rows)];            
              %% 6th Layer
            a6 = W1e*h5;
            h6 = 1./(1+exp(-a6));
            h6 = [h6; ones(1,rows)];      
            %% 7th Layer
            a7 = W1f*h6;
            h7 = 1./(1+exp(-a7));
            h7 = [h7; ones(1,rows)];            
            %% 8th Layer
            a8 = W1g*h7;
            h8 = 1./(1+exp(-a8));
            h8 = [h8; ones(1,rows)];                       
            %% Output Layer
            %         a1_3 = W11_3*h1_2 + W12_3*h2_2 + b11_3; %Output Neuron 1
            %         h1_3(m) = 1/(1+exp(-a1_3)); %Output Neuron 1 Hypothesis
            %         del1_3 = (h1_3(m) - y(m))*h1_3(m)*(1-h1_3(m)); % del function
            aa1_3 = W2*h8;
            h11_3 = 1./(1+exp(-aa1_3));
            v1 = (1-h11_3)'*h11_3;
            v2 = (h11_3' - y(m));
            del11_3 = v1*v2;
            %% Backward Propagation
            % Output Layer Weights
            a22 = h8*del11_3;
            W2 = W2'-alpha.*a22;            
            %% 8th Hidden Layer Weights
            uu1 = h8(1:end-1,:)'*(1-h8(1:end-1,:));
            uu2 = del11_3*W2(1:end-1)';
            uu3 = uu1*uu2;
            uu4 = x(:,m)*uu3;
            W1g = W1g' - alpha.*uu4;
            %% 7th Hidden Layer Weights
            vv1 = uu1*h7(1:end-1,:)'*(1-h7(1:end-1,:));
            vv2 = del11_3*W2(1:end-1)';
            vv3 = vv1*vv2;
            vv4 = x(:,m)*vv3;
            W1f = W1f' - alpha.*vv4;
            %% 6th Hidden Layer Weights
            qq1 = vv1*h6(1:end-1,:)'*(1-h6(1:end-1,:));
            qq2 = del11_3*W2(1:end-1)';
            qq3 = qq1*qq2;
            qq4 = x(:,m)*qq3;
            W1e = W1e' - alpha.*qq4;            
            %% 5th Hidden Layer Weights
            zz1 = qq1*h5(1:end-1,:)'*(1-h5(1:end-1,:));
            zz2 = del11_3*W2(1:end-1)';
            zz3 = zz1*zz2;
            zz4 = x(:,m)*zz3;
            W1d = W1d' - alpha.*zz4;
            %% 4th Hidden Layer Weights
            gg1 = zz1*h4(1:end-1,:)'*(1-h4(1:end-1,:));
            gg2 = del11_3*W2(1:end-1)';
            gg3 = gg1*gg2;
            gg4 = x(:,m)*gg3;
            W1c = W1c' - alpha.*gg4;
            %% 3rd Hidden Layer Weights
            hh1 =  gg1*h3(1:end-1,:)'*(1-h3(1:end-1,:));
            hh2 = del11_3*W2(1:end-1)';
            hh3 = hh1*hh2;
            hh4 = x(:,m)*hh3;
            W1b = W1b' - alpha.*hh4;            
            %% 2nd Hidden Layer Weights
            ii1 = hh1*h2(1:end-1,:)'*(1-h2(1:end-1,:));
            ii2 = del11_3*W2(1:end-1)';
            ii3 = ii1*ii2;
            ii4 = x(:,m)*ii3;
            W1a = W1a' - alpha.*ii4;            
            %% 1st Hidden Layer Weights
            kk1 = ii1*h1(1:end-1,:)'*(1-h1(1:end-1,:)); 
            kk2 = del11_3*W2(1:end-1)';
            kk3 = kk1*kk2;
            kk4 = x(:,m)*kk3;
            W1 = W1' - alpha.*kk4;            
%%            %%
            W1 = W1';
            W1a = W1a';
            W1b = W1b';
            W1c = W1c';
            W1d = W1d';
            W1e = W1e';
            W1f = W1f';
            W1g = W1g';
%             W1h = W1h';
%             W1i = W1i';
%             W1j = W1j';
%             W1k = W1k';
%             W1l = W1l';
            W2 = W2';
            new_h11_3(m) = h11_3;
            new_y(m) = y(m);
            test1 = [new_h11_3 y(m)];
        end
    end
    % test = [h11_3' y(m)]
    test = [new_h11_3(:) new_y(:)]
end